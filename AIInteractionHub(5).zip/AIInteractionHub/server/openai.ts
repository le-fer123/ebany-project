import OpenAI from "openai";
import { generateGeminiResponse } from "./gemini";

if (!process.env.OPENAI_API_KEY) {
  throw new Error("Missing OPENAI_API_KEY environment variable");
}

export const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY
});

const AVAILABLE_MODELS = [
  {
    name: "gpt-3.5-turbo",
    maxTokens: 500,
    priority: 1
  },
  {
    name: "gpt-3.5-turbo-instruct",
    maxTokens: 300,
    priority: 2
  }
];

export async function generateAIResponse(userMessage: string): Promise<{ content: string; model: string }> {
  let lastError: Error | null = null;

  // Try Gemini first
  try {
    console.log('Attempting to use Gemini');
    const response = await generateGeminiResponse(userMessage);
    console.log('Successfully generated response using Gemini');
    return { content: response, model: 'gemini-pro' };
  } catch (error) {
    console.error('Gemini failed:', error);
    lastError = error;
  }

  // Try OpenAI models as fallback
  for (const model of AVAILABLE_MODELS) {
    try {
      console.log(`Attempting to use OpenAI model: ${model.name}`);
      const completion = await openai.chat.completions.create({
        messages: [
          { 
            role: "system", 
            content: "Вы - ИИ-ассистент, который отвечает ТОЛЬКО на вопросы об устройстве нейросетей и фундаментальных принципах функционирования искусственного интеллекта. Если пользователь спрашивает о чем-то другом (например, о рецептах, советах, личной информации и т.д.), вежливо объясните, что вы запрограммированы отвечать только на вопросы о нейросетях и ИИ. Будьте информативны и точны в своих ответах по теме ИИ."
          },
          { 
            role: "user", 
            content: userMessage 
          }
        ],
        model: model.name,
        temperature: 0.7,
        max_tokens: model.maxTokens
      });

      const response = completion.choices[0]?.message?.content;
      if (!response) {
        throw new Error("No response generated");
      }

      console.log(`Successfully generated response using OpenAI model: ${model.name}`);
      return { content: response, model: model.name };
    } catch (error: any) {
      console.error(`Error with OpenAI model ${model.name}:`, error);
      lastError = error;
    }
  }

  // Handle the case where all models failed
  console.error('All AI models failed:', lastError);
  return {
    content: "I encountered an unexpected error. Please try your question again or rephrase it differently.",
    model: "fallback"
  };
}