import { GoogleGenerativeAI } from "@google/generative-ai";

if (!process.env.GOOGLE_AI_KEY) {
  throw new Error("Missing GOOGLE_AI_KEY environment variable");
}

const genAI = new GoogleGenerativeAI(process.env.GOOGLE_AI_KEY);

export async function generateGeminiResponse(userMessage: string): Promise<string> {
  try {
    console.log('Initializing Gemini model...');
    const model = genAI.getGenerativeModel({ model: "gemini-2.0-flash" });

    console.log('Sending request to Gemini API...');
    const result = await model.generateContent({
      contents: [
        { 
          role: "user",
          parts: [{ text: "Ты - ИИ-ассистент, который отвечает ТОЛЬКО на вопросы об устройстве нейросетей и фундаментальных принципах функционирования искусственного интеллекта. Если я спрашиваю о чем-то другом (например, о рецептах, советах, личной информации и т.д.), вежливо объясни, что ты запрограммирован отвечать только на вопросы о нейросетях и ИИ. Будь информативен и точен в своих ответах по теме ИИ." }]
        },
        { 
          role: "model",
          parts: [{ text: "Понял. Я буду отвечать только на вопросы о нейросетях и принципах работы искусственного интеллекта. Если вопрос будет о чем-то другом, я вежливо объясню ограничения моей функциональности." }]
        },
        { 
          role: "user",
          parts: [{ text: userMessage }]
        }
      ],
      generationConfig: {
        temperature: 0.7,
        maxOutputTokens: 500,
      },
    });

    console.log('Received response from Gemini API');
    const response = result.response;
    return response.text();
  } catch (error) {
    console.error('Gemini API Error:', error);
    throw new Error(`Gemini API Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }
}