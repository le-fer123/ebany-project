import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertMessageSchema } from "@shared/schema";
import { generateAIResponse } from "./openai";
import { generateGeminiResponse } from "./gemini";

export async function registerRoutes(app: Express): Promise<Server> {
  // Генерировать список уникальных вопросов о нейросетях
  app.get("/api/generate-questions", async (_req, res) => {
    try {
      const prompt = "Сгенерируй 5 уникальных вопросов о нейросетях и искусственном интеллекте. Вопросы должны быть разнообразными, охватывающими разные аспекты ИИ. Верни их в формате JSON-массива без дополнительного текста. Например: [\"Вопрос 1\", \"Вопрос 2\", \"Вопрос 3\", \"Вопрос 4\", \"Вопрос 5\"]";
      
      try {
        // Пытаемся использовать Gemini
        const response = await generateGeminiResponse(prompt);
        
        // Обрабатываем ответ, чтобы извлечь корректный JSON
        let jsonStr = response;
        
        // Ищем квадратные скобки и содержимое между ними
        const bracketMatch = response.match(/\[.*?\]/s);
        if (bracketMatch) {
          jsonStr = bracketMatch[0];
        }
        
        try {
          const questions = JSON.parse(jsonStr);
          if (Array.isArray(questions)) {
            res.json({ questions });
            return;
          }
        } catch (jsonError) {
          console.error('Error parsing JSON response:', jsonError);
        }
        
        // Если не удалось распарсить JSON, пытаемся извлечь вопросы по паттерну
        const questionsRegex = /"([^"]+)"/g;
        const matches = [...response.matchAll(questionsRegex)];
        const extractedQuestions = matches.map(match => match[1]);
        
        if (extractedQuestions.length > 0) {
          res.json({ questions: extractedQuestions });
          return;
        }
        
        // Если ничего не сработало, возвращаем запасные вопросы
        res.json({ 
          questions: [
            "Что такое нейронные сети?",
            "Как работает машинное обучение?",
            "Объясните принцип работы трансформеров",
            "В чем разница между ИИ и машинным обучением?",
            "Что такое глубокое обучение?"
          ]
        });
      } catch (error) {
        console.error('Error generating questions:', error);
        res.json({ 
          questions: [
            "Что такое нейронные сети?",
            "Как работает машинное обучение?",
            "Объясните принцип работы трансформеров",
            "В чем разница между ИИ и машинным обучением?",
            "Что такое глубокое обучение?"
          ]
        });
      }
    } catch (error) {
      console.error('Error in generate-questions endpoint:', error);
      res.status(500).json({ error: "Failed to generate questions" });
    }
  });
  // Создать новую сессию
  app.get("/api/session", async (_req, res) => {
    try {
      const sessionId = await storage.createSession();
      res.setHeader('Content-Type', 'application/json');
      res.json({ sessionId });
    } catch (error) {
      console.error('Error creating session:', error);
      res.status(500).json({ error: "Failed to create session" });
    }
  });

  // Получить сообщения для конкретной сессии
  app.get("/api/messages/:sessionId", async (req, res) => {
    try {
      const { sessionId } = req.params;
      const messages = await storage.getMessages(sessionId);
      res.setHeader('Content-Type', 'application/json');
      res.json(messages);
    } catch (error) {
      console.error('Error fetching messages:', error);
      res.status(500).json({ error: "Failed to fetch messages" });
    }
  });

  // Тестовый эндпоинт для Gemini
  app.get("/api/test-gemini", async (_req, res) => {
    try {
      const testMessage = "Hello, can you introduce yourself?";
      console.log('Testing Gemini API with message:', testMessage);
      const response = await generateGeminiResponse(testMessage);
      res.json({ success: true, response });
    } catch (error) {
      console.error('Gemini test endpoint error:', error);
      res.status(500).json({ 
        success: false, 
        error: error instanceof Error ? error.message : 'Unknown error',
        errorDetails: error 
      });
    }
  });

  app.post("/api/messages", async (req, res) => {
    try {
      const parsed = insertMessageSchema.safeParse(req.body);
      if (!parsed.success) {
        res.status(400).json({ error: "Invalid message format" });
        return;
      }

      const message = await storage.createMessage(parsed.data);

      // Генерируем ответ от ИИ на сообщения пользователя
      if (parsed.data.role === "user") {
        try {
          const aiResponse = await generateAIResponse(parsed.data.content);
          await storage.createMessage({
            sessionId: parsed.data.sessionId,
            role: "assistant",
            content: aiResponse.content,
            model: aiResponse.model
          });
        } catch (error) {
          console.error('Failed to generate AI response:', error);
          // Создаем резервный ответ
          await storage.createMessage({
            sessionId: parsed.data.sessionId,
            role: "assistant",
            content: "I apologize, but I'm currently experiencing some technical difficulties. Please try again later.",
            model: "fallback"
          });
        }
      }

      res.json(message);
    } catch (error) {
      console.error('Error handling message:', error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}