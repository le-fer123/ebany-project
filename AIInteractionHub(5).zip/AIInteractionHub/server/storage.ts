
import { messages, type Message, type InsertMessage } from "@shared/schema";
import { v4 as uuidv4 } from 'uuid';

export interface IStorage {
  getMessages(sessionId: string): Promise<Message[]>;
  createMessage(message: InsertMessage): Promise<Message>;
  createSession(): Promise<string>;
}

export class MemStorage implements IStorage {
  private messages: Message[];
  private currentId: number;

  constructor() {
    this.messages = [];
    this.currentId = 1;
  }

  async getMessages(sessionId: string): Promise<Message[]> {
    return this.messages.filter(msg => msg.sessionId === sessionId);
  }

  async createMessage(insertMessage: InsertMessage): Promise<Message> {
    const message: Message = {
      id: this.currentId++,
      sessionId: insertMessage.sessionId,
      content: insertMessage.content,
      role: insertMessage.role,
      model: insertMessage.model || "unknown",
      timestamp: new Date()
    };
    this.messages.push(message);
    return message;
  }

  async createSession(): Promise<string> {
    return uuidv4();
  }
}

export const storage = new MemStorage();
