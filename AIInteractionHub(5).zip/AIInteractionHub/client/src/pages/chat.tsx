
import React from 'react';
import ChatContainer from '../components/chat/chat-container';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';

const ChatPage: React.FC = () => {
  return (
    <div className="container mx-auto p-4 h-screen flex flex-col">
      <Card className="flex-1 flex flex-col overflow-hidden">
        <CardHeader className="bg-card border-b">
          <CardTitle>ИИ-Ассистент по нейросетям</CardTitle>
        </CardHeader>
        <CardContent className="p-0 flex-1 overflow-hidden">
          <ChatContainer />
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatPage;
