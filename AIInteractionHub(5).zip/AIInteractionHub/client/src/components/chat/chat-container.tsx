import React, { useEffect, useState, useRef } from 'react';
import MessageBubble from './message-bubble';
import { Message } from '@shared/schema';
import { v4 as uuidv4 } from 'uuid';
import { Card, CardContent } from '../ui/card';
import { Bot, Send } from 'lucide-react';
import { cn } from '@/lib/utils';

const ChatContainer: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [sessionId, setSessionId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [inputValue, setInputValue] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [presetQuestions, setPresetQuestions] = useState<string[]>([]);
  const [showPresetQuestions, setShowPresetQuestions] = useState(true); // Added state for showing/hiding buttons

  useEffect(() => {
    const storedSessionId = localStorage.getItem('chat_session_id');
    if (storedSessionId) {
      setSessionId(storedSessionId);
      fetchMessages(storedSessionId);
    } else {
      createNewSession();
    }
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const createNewSession = async () => {
    setLoading(true);
    try {
      const response = await fetch('/api/session');
      if (!response.ok) {
        throw new Error('Failed to create session');
      }

      const data = await response.json();
      const fallbackSessionId = data.sessionId || uuidv4();

      localStorage.setItem('chat_session_id', fallbackSessionId);
      setSessionId(fallbackSessionId);
      setLoading(false);

      // Получаем новые уникальные вопросы для новой сессии
      fetchPresetQuestions();
      setShowPresetQuestions(true); // Show buttons after new session
    } catch (error) {
      console.error('Error creating session:', error);
      const fallbackSessionId = uuidv4();
      localStorage.setItem('chat_session_id', fallbackSessionId);
      setSessionId(fallbackSessionId);
      setLoading(false);

      // Получаем новые уникальные вопросы для новой сессии
      fetchPresetQuestions();
      setShowPresetQuestions(true); // Show buttons after new session
    }
  };

  const fetchMessages = async (sid: string) => {
    try {
      setLoading(true);
      const response = await fetch(`/api/messages/${sid}`);
      if (!response.ok) {
        throw new Error(`Server returned ${response.status}: ${response.statusText}`);
      }
      const contentType = response.headers.get('content-type');
      if (!contentType || !contentType.includes('application/json')) {
        throw new Error(`Expected JSON response but got ${contentType}`);
      }
      const data = await response.json();
      setMessages(data);
      setLoading(false);
    } catch (error) {
      console.error('Error fetching messages:', error);
      setLoading(false);
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInputValue(e.target.value);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleSendMessage = async () => {
    if (!inputValue.trim() || !sessionId) return;

    // Скрываем кнопки с вопросами после первого сообщения
    setShowPresetQuestions(false);

    const tempId = Date.now();
    const userMessage: Partial<Message> = {
      id: tempId,
      sessionId,
      content: inputValue,
      role: 'user',
      timestamp: new Date(),
      model: 'user'
    };

    setInputValue('');

    setMessages(prev => [...prev, userMessage as Message]);

    try {
      const response = await fetch('/api/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          sessionId,
          content: userMessage.content,
          role: 'user'
        })
      });

      if (!response.ok) {
        throw new Error('Failed to send message');
      }

      fetchMessages(sessionId);
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  // Handle clicking a preset question
  const handlePresetQuestion = (question: string) => {
    setInputValue(question);
    setTimeout(() => {
      handleSendMessage();
    }, 10);
  };

  // Fetch additional preset questions from the AI (could be called on initial load)
  const fetchPresetQuestions = async () => {
    try {
      const response = await fetch('/api/generate-questions', {
        method: 'GET',
        headers: {
          'Content-Type': 'application/json'
        }
      });

      if (response.ok) {
        const data = await response.json();
        if (data.questions && Array.isArray(data.questions)) {
          setPresetQuestions(data.questions);
        }
      }
    } catch (error) {
      console.error('Error fetching preset questions:', error);
    }
  };

  // Effect to fetch preset questions once on mount
  useEffect(() => {
    fetchPresetQuestions();
  }, []);

  return (
    <div className="h-full flex flex-col">
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && !loading && (
          <div className="flex flex-col items-center justify-center h-full text-center text-muted-foreground">
            <Bot className="h-8 w-8 mb-4" />
            <h3 className="text-lg font-medium">Начните разговор с ИИ-ассистентом</h3>
            <p className="max-w-md">
              Задайте вопрос о принципах работы искусственного интеллекта и нейросетей
            </p>
          </div>
        )}
        {messages.map((message) => (
          <MessageBubble key={message.id} message={message} />
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="px-4 mb-2">
        {showPresetQuestions && ( // Conditionally render buttons
          <div className="flex flex-wrap gap-2 mb-2">
            {presetQuestions.map((question, index) => (
              <button
                key={index}
                className="px-3 py-1 bg-muted text-sm rounded-full hover:bg-primary hover:text-primary-foreground transition-colors"
                onClick={() => handlePresetQuestion(question)}
              >
                {question}
              </button>
            ))}
          </div>
        )}
      </div>

      <Card className="mx-4 mb-4">
        <CardContent className="p-4">
          <div className="flex items-end gap-2">
            <textarea
              className="flex-1 min-h-[40px] max-h-[200px] resize-y bg-background p-2 rounded-md border focus:outline-none focus:ring-2 focus:ring-primary"
              placeholder="Введите сообщение..."
              value={inputValue}
              onChange={handleInputChange}
              onKeyDown={handleKeyDown}
            />
            <button
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md self-end"
              onClick={handleSendMessage}
            >
              Отправить
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default ChatContainer;