import type { Message } from "@shared/schema";
import { cn } from "@/lib/utils";
import { AlertCircle, Bot } from "lucide-react";

interface MessageBubbleProps {
  message: Message;
}

// Function to format text with basic markdown
const formatText = (text: string): React.ReactNode => {
  if (!text) return '';

  // Split by asterisks for bold formatting
  const parts = text.split(/(\*\*.*?\*\*)/g);

  return parts.map((part, index) => {
    // Check if part is bold (wrapped in **)
    if (part.startsWith('**') && part.endsWith('**')) {
      const content = part.slice(2, -2);
      return <strong key={index}>{content}</strong>;
    }

    // Handle other formatting patterns if needed
    // e.g., *italic* or _italic_
    if ((part.startsWith('*') && part.endsWith('*') && !part.startsWith('**')) || 
        (part.startsWith('_') && part.endsWith('_'))) {
      const content = part.slice(1, -1);
      return <em key={index}>{content}</em>;
    }

    // Regular text
    return part;
  });
};

export default function MessageBubble({ message }: MessageBubbleProps) {
  const isUser = message.role === "user";
  const isError = message.content.includes("experiencing some technical difficulties");

  return (
    <div
      className={cn(
        "flex",
        isUser ? "justify-end" : "justify-start"
      )}
    >
      <div
        className={cn(
          "rounded-lg px-4 py-2 max-w-[80%]",
          isUser
            ? "bg-primary text-primary-foreground"
            : isError
              ? "bg-destructive/10 text-destructive border border-destructive/20"
              : "bg-muted"
        )}
      >
        {!isUser && (
          <div className="flex items-center gap-2 mb-2">
            <Bot className="h-4 w-4" />
            <span className="text-xs font-medium opacity-70">
              {message.model === "fallback" ? "ИИ-Ассистент" : message.model === "gemini-pro" ? "ИИ-Ассистент" : message.model}
            </span>
          </div>
        )}
        {isError && !isUser && (
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="h-4 w-4" />
            <span className="text-sm font-medium">API Error</span>
          </div>
        )}
        <p className="text-sm whitespace-pre-wrap">{formatText(message.content)}</p>
        <p className="text-xs opacity-70 mt-1">
          {new Date(message.timestamp).toLocaleTimeString()}
        </p>
      </div>
    </div>
  );
}